Container for arbitrary data needed by tests
============================================

You can refer to files from this directory, in your scripts, using
the $PLAINBOX\_PROVIDER\_DATA environment variable. See the job
examples/data-access for details.

You should delete this file as anything here is automatically
distributed in the source tarball or installed.