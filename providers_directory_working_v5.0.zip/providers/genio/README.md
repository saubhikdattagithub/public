Checkbox Provider - Genio
=========================

A provider in which to land tests for the Genio partnership.

That is it for now. You should check out the official documentation
for test authors at
https://checkbox.readthedocs.io/en/latest/index.html
