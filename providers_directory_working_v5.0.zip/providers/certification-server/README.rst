Server Certification Provider is a collection of tests for server hardware.
It is used together alongside with PlainBox
