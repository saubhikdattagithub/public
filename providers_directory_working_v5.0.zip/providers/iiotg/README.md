Checkbox Provider - IIoTG
=========================

A provider in which to land tests for the IIoTG partnership.

That is it for now. You should check out the official documentation
for test authors at
https://checkbox.readthedocs.io/en/latest/index.html

If you find bugs or would like to see additional features developed
you can file bugs on the parent project page:
https://bugs.launchpad.net/checkbox-provider-iiotg/+filebug
