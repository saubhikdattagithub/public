Generic Resources Provider is a collection of resources tests to express job
requirements. It is used together alongside with PlainBox
