Plainbox Provider for Kernel SRU testing
========================================

This provider contains test cases and a test plan for kernel SRU testing.
See https://wiki.ubuntu.com/Kernel/kernel-sru-workflow
